#include <iostream.h>
#include <windows.h>
#include <wingdi.h>
#include <SDL.h>
#include <GL\gl.h>
#include <GL\glu.h>

#include "utils\math3d.cpp"
#define NDEBUG
#include <assert.h>

#ifndef NDEBUG
#define TRACE(STRING) { cout << endl << STRING; }
#define TRACEV(STRING, value) { cout << endl << STRING << value; }
#else
#define TRACE(STRING) (void)0;
#define TRACEV(STRING, value) (void)0;
#endif

class Facet3d 
{
public:
friend class CubeThread;
	Facet3d() {};
	Facet3d(Vect_3d &v1, Vect_3d &v2, Vect_3d &v3, Vect_3d &v4);
	Facet3d(float *cords);
	void Transform(Facet3d &source, Matrix &m);
	void Transform(Facet3d &source, Matrix &m, Vect_3d &zero);
	void Translate(Vect_3d &point);
private:
	Vect_3d v[4];
};

class CubeThread 
{
public:
	CubeThread(); 
	~CubeThread() { for(int i = 0; i < 6; i++) delete fac[i]; delete[] coords, fac;};
	void init(void);
	void update(void);
	Uint32 time_check(void);
	void setTime(Uint32 time) { next_time = time; };
	void incrTime(Uint32 time) { next_time += time; };
	void handle_key_down( SDL_keysym* keysym );
private:
	GLboolean should_rotate; 
	Uint32 next_time;
	Facet3d *fac[6];
	GLfloat *coords;
	int angle;
	GLboolean lighting;
};

static void quit( int code )
{
	/*
	* Quit SDL so we can release the fullscreen
	* mode and restore the previous video settings,
	* etc.
	*/
	SDL_Quit( );
	
	/* Exit program. */
	exit( code );
}

static void setup_opengl( int width, int height )
{
	float ratio = (float) width / (float) height;
	GLfloat mat_specular[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat light_position[] = {100.0f, 600.0f, 600.0f, 1.0f};
	GLfloat light_color[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	
	/* Our shading model--Gouraud (smooth). */
	glShadeModel( GL_SMOOTH );
	
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light_color);
	glLightfv(GL_LIGHT0, GL_SPECULAR, light_color);
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular);
	glEnable(GL_LIGHTING);
	
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_POLYGON_SMOOTH);
	glEnable(GL_POINT_SMOOTH);
	glPointSize(5.0f);

	/* Culling. */
//	glCullFace( GL_BACK );
//	glFrontFace( GL_CCW );
//	glEnable( GL_CULL_FACE );
	
	/* Set the clear color. */
	glClearColor( 0.0f, 0.0f, 0.0f, 0.0f );
	
	/* Setup our viewport. */
	glViewport( 0, 0, width, height );
	
	/*
	* Change to the projection matrix and set
	* our viewing volume.
	*/
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity( );
	/*
	* EXERCISE:
	* Replace this with a call to glFrustum.
	*/
	gluPerspective( 30.0f, ratio, 1.0f, 1024.0f );
}

static void process_events( CubeThread &pgm )
{
	/* Our SDL event placeholder. */
	SDL_Event event;
	
	/* Grab all the events off the queue. */
	while( SDL_PollEvent( &event ) ) 
	{
		switch( event.type ) 
		{
			case SDL_KEYDOWN:
				/* Handle key presses. */
				pgm.handle_key_down( &event.key.keysym );
				break;
			case SDL_QUIT:
				/* Handle quit requests (like Ctrl-c). */
				quit( 0 );
			break;
		}	
	}	
}


CubeThread::CubeThread()
: angle(0), should_rotate(GL_TRUE), lighting(GL_TRUE)
{ 
	for(int i = 0; i < 6; i++)
		fac[i] = new Facet3d;
	coords = new GLfloat[6*4*3]; //Number of faces * number of vertices/face * number of dimensions
}
void CubeThread::init(void)
{	
	Matrix mx(3), mx2(3), my(3);
	rot_matr(my, y, 90.0);
	rot_matr(mx, x, 90.0);
	rot_matr(mx2, x, -90.0);

//	rot_matrxyz(my, 90.0, 0.0, 1.0, 0.0);
//	rot_matrxyz(mx, -90.0, 1.0, 0.0, 0.0);
//	rot_matrxyz(mx2, 90.0, 1.0, 0.0, 0.0);

#define S 64
	float c[] = 
	{
		-S, -S, S,
		S, -S, S,
		S, S, S,
		-S, S, S 
	};
	
	*fac[0] = Facet3d(c);
		
	Vect_3d trany(0, 8, 0);
	Vect_3d tranx(8, 0, 0);
	Vect_3d tranz(0, 0, 8);
	Vect_3d trany2(0, -8, 0);
	Vect_3d tranx2(-8, 0, 0);
	Vect_3d tranz2(0, 0, -8);
	
	fac[1]->Transform(*fac[0], my);
	fac[2]->Transform(*fac[1], my);
	fac[3]->Transform(*fac[2], my);
	fac[4]->Transform(*fac[0], mx);
	fac[5]->Transform(*fac[0], mx2);
	
	fac[0]->Translate(tranz);
	fac[1]->Translate(tranx);
	fac[2]->Translate(tranz2);
	fac[3]->Translate(tranx2);
	fac[4]->Translate(trany2);
	fac[5]->Translate(trany);
	
	for(int i=0, j=0; i<6; i++, j+=12)
	{
		coords[j] 		=	(GLfloat)fac[i]->v[0](0);
		coords[j+1]		=	(GLfloat)fac[i]->v[0](1);
		coords[j+2]		=	(GLfloat)fac[i]->v[0](2);
		coords[j+3]		=	(GLfloat)fac[i]->v[1](0);
		coords[j+4]		=	(GLfloat)fac[i]->v[1](1);
		coords[j+5]		=	(GLfloat)fac[i]->v[1](2);
		coords[j+6]		=	(GLfloat)fac[i]->v[2](0);
		coords[j+7]		=	(GLfloat)fac[i]->v[2](1);
		coords[j+8]		=	(GLfloat)fac[i]->v[2](2);
		coords[j+9]		=	(GLfloat)fac[i]->v[3](0);
		coords[j+10]	=	(GLfloat)fac[i]->v[3](1);
		coords[j+11]	=	(GLfloat)fac[i]->v[3](2);
	}				
}


void CubeThread::update(void)
{
	GLfloat mat_shininess[1] = { 50.0f } ;
	/* Ambient and diffuse colors for the cube faces */
	GLfloat mat_amb_diff[][4] = { 	{1.0f, 0.0f, 0.0f, 1.0f}, {0.0f, 1.0f, 0.0f, 1.0f }, {0.0f, 0.0f, 1.0f, 1.0f}, 
									{1.0f, 1.0f, 0.0f, 1.0f}, {0.0f, 1.0f, 1.0f, 1.0f }, {1.0f, 0.0f, 1.0f, 0.5f}};

	/* Cube face normals */
	GLfloat n[][3] = { 	{ 0.0f, 0.0f, 1.0f },
						{1.0f, 0.0f, 0.0f },
						{0.0f, 0.0f, -1.0f }, 
						{-1.0f, 0.0f, 0.0f },
						{0.0f, -1.0f, 0.0f},
						{0.0f, 1.0f, 0.0f}	};
	
	/* Clear the color and depth buffers. */
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT ); 
	
	/* We don't want to modify the projection matrix. */
	
	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity( );	


	if( should_rotate ) 
	{		
		if( angle++ > 360 ) 
			angle = 0;	
	}

	
	if(lighting)
		glEnable(GL_LIGHT0);
	else
		glDisable(GL_LIGHT0);

	/* Move down the z-axis. */
	
	glTranslatef( 0.0f, 0.0f, -500.0f );

	/* Rotate. */

	glRotatef(angle, 1.0f, 0.0f, 0.0f);
	glRotatef(angle, 0.0f, 1.0f, 0.0f);
	glRotatef(angle, 0.0f, 0.0f, 1.0f);
	
	/* Send our polygon data to the pipeline. */
	glBegin( GL_QUADS );
	for(int i=0, j=0; i<60; i+=12, j++)
	{
		glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
		glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, &mat_amb_diff[j][0]);

		glNormal3fv(n[j]);
		glVertex3fv(&coords[i]);
		glVertex3fv(&coords[i+3]);
		glVertex3fv(&coords[i+6]);
		glVertex3fv(&coords[i+9]);
	}
	glEnd( );
	
	glDepthMask(GL_FALSE);

	glBegin( GL_QUADS );

	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, &mat_amb_diff[5][0]);

	glNormal3fv(n[5]);
	glVertex3fv(&coords[60]);
	glVertex3fv(&coords[63]);
	glVertex3fv(&coords[66]);
	glVertex3fv(&coords[69]);

	glEnd( );
	
		
	glDepthMask(GL_TRUE);	
	
	
	/*
	* Swap the buffers. This tells the driver to
	* render the next frame from the contents of the
	* back-buffer, and to set all rendering operations
	* to occur on what was the front-buffer.
	*
	* Double buffering prevents nasty visual tearing
	* from the application drawing on areas of the
	* screen that are being updated at the same time.
	*/
	glFlush();
	SDL_GL_SwapBuffers( );	
}

Uint32 CubeThread::time_check(void)
{
	Uint32 now = SDL_GetTicks();
	if(next_time <= now)
		return 0;
	else
		return next_time - now;
}

void CubeThread::handle_key_down( SDL_keysym* keysym )
{
	/*
	* We're only interested if 'Esc' has
	* been presssed.
	*
	* EXERCISE:
	* Handle the arrow keys and have that change the
	* viewing position/angle.
	*/
	switch( keysym->sym ) 
	{
		case SDLK_ESCAPE:
			quit( 0 );
			break;
		case SDLK_SPACE:
			lighting = !lighting;
			break;
		case SDLK_RETURN:
			should_rotate = !should_rotate;
			break;
		default:
			break;
	}	
}


Facet3d::Facet3d(Vect_3d &v1, Vect_3d &v2, Vect_3d &v3, Vect_3d &v4)
{
	v[0] = v1;
	v[1] = v2;
	v[2] = v3;
	v[3] = v4;
}

Facet3d::Facet3d(float *coords)
{
	int i, p;
	for(p = 0, i = 0; p < 4; p++)
	{
		v[p].ins(0, coords[i++]);
		v[p].ins(1, coords[i++]);
		v[p].ins(2, coords[i++]);
	}
}

void Facet3d::Transform(Facet3d &source, Matrix &m)
{
	transform(source.v[0], v[0], m);
	transform(source.v[1], v[1], m);
	transform(source.v[2], v[2], m);
	transform(source.v[3], v[3], m);
}

void Facet3d::Transform(Facet3d &source, Matrix &m, Vect_3d &zero)
{
	transform(source.v[0], v[0], m, zero);
	transform(source.v[1], v[1], m, zero);
	transform(source.v[2], v[2], m, zero);
	transform(source.v[3], v[3], m, zero);
}


void Facet3d::Translate(Vect_3d &point)
{
	for(int i = 0; i < 4; i++)
		v[i] = v[i] + point;
}



main(int argc, char *argv[])
{
	/* Information about the current video settings. */
	const SDL_VideoInfo* info = NULL;
	/* Dimensions of our window. */
	int width = 0;
	int height = 0;
	/* Color depth in bits of our window. */
	int bpp = 0;
	/* Flags we will pass into SDL_SetVideoMode. */
	int flags = 0;
	
	/* First, initialize SDL's video subsystem. */
	if( SDL_Init( SDL_INIT_VIDEO ) < 0 ) 
	{
		/* Failed, exit. */
		cerr << "Video initialization failed: " << SDL_GetError( ) << endl;
		quit( 1 );
	}
	
	/* Let's get some video information. */
	info = SDL_GetVideoInfo( );
	
	if( !info ) 
	{
		/* This should probably never happen. */
		cerr << "Video query failed: " << SDL_GetError( ) << endl;
		quit( 1 );
	}
	
	/*
	* Set our width/height to 640/480 (you would
	* of course let the user decide this in a normal
	* app). We get the bpp we will request from
	* the display. On X11, VidMode can't change
	* resolution, so this is probably being overly
	* safe. Under Win32, ChangeDisplaySettings
	* can change the bpp.
	*/
	width = 800;
	height = 600;
	bpp = info->vfmt->BitsPerPixel;
	
	/*
	* Now, we want to setup our requested
	* window attributes for our OpenGL window.
	* We want *at least* 5 bits of red, green
	* and blue. We also want at least a 16-bit
	* depth buffer.
	*
	* The last thing we do is request a double
	* buffered window. '1' turns on double
	* buffering, '0' turns it off.
	*
	* Note that we do not use SDL_DOUBLEBUF in
	* the flags to SDL_SetVideoMode. That does
	* not affect the GL attribute state, only
	* the standard 2D blitting setup.
	*/
	SDL_GL_SetAttribute( SDL_GL_RED_SIZE, 5 );
	SDL_GL_SetAttribute( SDL_GL_GREEN_SIZE, 5 );
	SDL_GL_SetAttribute( SDL_GL_BLUE_SIZE, 5 );
	SDL_GL_SetAttribute( SDL_GL_DEPTH_SIZE, 16 );
	SDL_GL_SetAttribute( SDL_GL_DOUBLEBUFFER, 1 );
	
	/*
	* We want to request that SDL provide us
	* with an OpenGL window, in a fullscreen
	* video mode.
	*
	* EXERCISE:
	* Make starting windowed an option, and
	* handle the resize events properly with
	* glViewport.
	*/
	flags = SDL_OPENGL; // | SDL_FULLSCREEN
	
	/*
	* Set the video mode
	*/
	if( SDL_SetVideoMode( width, height, bpp, flags ) == 0 ) 
	{
		/*
		* This could happen for a variety of reasons,
		* including DISPLAY not being set, the specified
		* resolution not being available, etc.
		*/
		cerr << "Video mode set failed: " << SDL_GetError( ) << endl;
		quit( 1 );
	}
	
	/*
	* At this point, we should have a properly setup
	* double-buffered window for use with OpenGL.
	*/
	setup_opengl( width, height );
	
	/*
	* Now we want to begin our normal app process--
	* an event loop with a lot of redrawing.
	*/
	
	CubeThread pgm;
		
	SDL_WM_SetCaption("Spinning Cube. v1.0", 0);
//	SDL_EnableUNICODE(1);
//	SDL_ShowCursor(SDL_ENABLE);
	
	
	pgm.init();
	
	
	pgm.setTime(SDL_GetTicks() + 10);
	
	while(1) 
	{
		pgm.update();
		process_events(pgm);
		/* Draw the screen. */
		SDL_Delay(pgm.time_check());
		pgm.incrTime(10);
	}
	
	/* Never reached */
}
